#ifndef UNICODE
#define UNICODE
#endif

#include <stdio.h>
#include <assert.h>
#include <windows.h>
#include <lm.h>
#include <activeds.h>
#include <initguid.h>

// Include the javah generated JNI header definitions
#include "com_isocra_utils_javaADSI_ADSIUtil.h"

/***************************************************************************
* Converts a wide string (two bytes per character) as returned by the WIN32
NetGroup API functions, into an ASCI string - the format in which it is needed.
***************************************************************************/

char* W2CA(const WCHAR* wideStr) {
   int wideLen = 255; // wstrlen(wideStr);
   char* asciStr = new char[wideLen+2];

   WideCharToMultiByte(
      CP_ACP,
      WC_COMPOSITECHECK,
      (LPCWSTR)wideStr,
      -1,
      asciStr,
      wideLen+1,
      NULL,
      NULL
   );

   return asciStr;
}

/***************************************************************************
* Java callable function which takes the address of a java string array
* and a user (as a JString)
***************************************************************************/
JNIEXPORT jobjectArray JNICALL Java_com_isocra_utils_javaADSI_ADSIUtil_groupsForUser
  (JNIEnv *env, jclass caller, jstring jUsername)
{

    // Get the username out of the environment
    const char *user = env->GetStringUTFChars(jUsername, 0);
    // Initialise the array that we're going to return
    jobjectArray jarray = NULL;

    // Now we have to make up the string that we're going to pass to ADsGetObject
    char adsPath[80];
    strcpy(adsPath, "WinNT://");
    strcat(adsPath, user);
    fprintf(stdout, "adsPath is '%s'\n", adsPath);

    // Call CoInitialize to initialise COM
    fprintf(stdout, "Starting up, calling CoInitialise\n");
    CoInitialize(NULL);

    // Convert the adsPath to wide chars so that we can pass it to ADsGetObject
    int nLen = strlen(adsPath) + 1;
    WCHAR* widePath = new WCHAR [nLen];
    mbstowcs(widePath, adsPath, nLen);

    // Now set up the required variables and call ADSGetObject
    fprintf(stdout, "Now calling ADsGetObject\n");
    IADsUser *pUser;
    HRESULT hr = ADsGetObject(widePath,
                IID_IADsUser,
                (void**) &pUser );
    fprintf(stdout, "Finished calling ADsGetObject\n");

    // If ADsGetObject can't return the user, we can stop now
    if(FAILED(hr)) {
        fprintf(stderr, "Got an error getting the user: %x", hr);
        return NULL;
    }

    // Now let's get the groups
    IADsMembers *pGroups;
    hr = pUser->Groups(&pGroups);
    if(FAILED(hr)) {
        fprintf(stderr, "Got an error getting the groups: %x", hr);
        return NULL;
    }
    // Don't need the user any more
    pUser->Release();

    // In order to iterate through the groups we need to get an enumerator
    // We then don't need the groups object itself any more so we can release it
    IUnknown *pUnk;
    hr = pGroups->get__NewEnum(&pUnk);
    if (FAILED(hr)) {
        fprintf(stderr, "Got an error getting the enumeration: %x", hr);
        return NULL;
    }
    pGroups->Release();

    // From IUnknown interface, we can query to get the EnumVARIANT interface
    IEnumVARIANT *pEnum;
    hr = pUnk->QueryInterface(IID_IEnumVARIANT,(void**)&pEnum);
    if (FAILED(hr)) {
        fprintf(stderr, "Got an error getting the enumeration variant: %x", hr);
        return NULL;
    }
    // Once we've got the interface we want, we can release the original one
    pUnk->Release();

    // Finally we can go round and enumerate the groups
    BSTR bstr;
    VARIANT var;
    IADs *pADs;
    ULONG lFetch;
    IDispatch *pDisp;

    // First we need to count the number of groups so that we can set the
    // Java array to the right size. There may be a more elegant way to do this...
    int size = 0;
    hr = pEnum->Next(1, &var, &lFetch);
    while(hr == S_OK && lFetch == 1)
    {
        size++;
        // Now go and get the next group
        hr = pEnum->Next(1, &var, &lFetch);
    }
    // Now we know the size, we reset the enumeration
    pEnum->Reset();

    // With the size, we can now create the object array we need
    jarray = env->NewObjectArray(size,
                                 env->FindClass("java/lang/String"),
                                 NULL);

    // Initialise the variant we're going to use for the individual groups
    VariantInit(&var);

    // Get the first group again
    hr = pEnum->Next(1, &var, &lFetch);

    // Keep a counter so we know where we are in the java array
    int i = 0;

    while(hr == S_OK && lFetch == 1)
    {
        // Now we need to get the IADs interface, so we use QueryInterface again
        pDisp = V_DISPATCH(&var);
        pDisp->QueryInterface(IID_IADs, (void**)&pADs);
        // Get the name of the group so that we can display it
        pADs->get_Name(&bstr);
        // Now fill the array with your either c or c++ strings.
        env->SetObjectArrayElement(jarray, i++, env->NewStringUTF(W2CA(bstr)));
        fprintf(stdout, "Group: %S\n",bstr);
        // Release the string because we don't need it any more
        SysFreeString(bstr);
        pADs->Release();
        // Now clear out the variant and we'll reuse it
        VariantClear(&var);
        // Now go and get the next one in the group
        hr = pEnum->Next(1, &var, &lFetch);
    };
    // We don't need the enumerator any more
    pEnum->Release();

    // We're done, so uninitialise the COM interface
    CoUninitialize();

    // Return the Java array of strings
    return jarray;
}

