/**
 * Copyright Isocra Ltd 2004
 * You can use, modify and freely distribute this file as long as you credit Isocra Ltd.
 * There is no explicit or implied guarantee of functionality associated with this file, use it at your own risk.
 */

package com.isocra.utils.javaADSI;

/**
 * This class provides an interface to the ADSI methods exposed by the C++ DLL
 */
public class ADSIUtil {

    /** returns an array of strings containing the groups for the current user */
    public static native String[] groupsForUser(String user);

    /** static library loading code - loads the external C++ DLL */
    static {
        System.loadLibrary("usergroups");
    }
}
