/**
 * Copyright Isocra Ltd 2004
 * You can use, modify and freely distribute this file as long as you credit Isocra Ltd.
 * There is no explicit or implied guarantee of functionality associated with this file, use it at your own risk.
 */

package com.isocra.utils.javaADSI;

/**
 * This class provides a very simple test harness for Isocra's
 * ADSI from Java example
 */
public class testJavaADSI {

    /** Simply take the username from the command line, call the ADSI
     * routine to get the list of users and write them out to System.out
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: testJavaADSI <username>");
        } else {
            String[] groups = ADSIUtil.groupsForUser(args[0]);
            if (groups != null) {
                System.out.println("testJavaADSI: "+args[0]+" belongs to " +
                        groups.length+" groups:");
                for (int i = 0; i < groups.length; i++) {
                    System.out.println("["+i+"] "+groups[i]);
                }
            } else {
                System.out.println("testJavaADSI: no groups returned");
            }
        }
    }
}
